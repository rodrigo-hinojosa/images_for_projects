<?php

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;

class UserStateTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        factory(App\UserState::class, 2)->create();

        DB::table('user_states')->insert([
            [
                'name' => 'ACTIVO',
                'icon' => 'check',
                'color_icon' => 'green-A700-fg',
                'description' => 'USUARIO ACTIVO EN PRODUCCION',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'name' => 'INACTIVO',
                'icon' => 'close',
                'color_icon' => 'red-A700-fg',
                'description' => 'USUARIO INACTIVO EN PRODUCCION',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
