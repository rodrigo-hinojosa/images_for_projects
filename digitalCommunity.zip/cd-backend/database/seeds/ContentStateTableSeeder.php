<?php

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;

class ContentStateTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        factory(App\ContentState::class, 2)->create();

        DB::table('content_states')->insert([
            [
                'name' => 'ACTIVO',
                'icon' => 'check',
                'color_icon' => 'green-A700-fg',
                'description' => 'CONTENIDO ACTIVO EN PRODUCCION',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'name' => 'INACTIVO',
                'icon' => 'close',
                'color_icon' => 'red-A700-fg',
                'description' => 'CONTENIDO INACTIVO EN PRODUCCION',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
