<?php

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;

class ContentTypeTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        factory(App\ContentType::class, 3)->create();

        DB::table('content_types')->insert([
            [
                'name' => 'NOTICIAS',
                'icon' => 'assistant_photo',
                'color_icon' => 'red-A700-fg',
                'description' => 'PUBLICACIONES CORRESPONDIENTES AL TIPO DE CONTENIDOS NOTICIAS',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'name' => 'EVENTOS',
                'icon' => 'group',
                'color_icon' => 'indigo-A700-fg',
                'description' => 'PUBLICACIONES CORRESPONDIENTES AL TIPO DE CONTENIDOS EVENTOS',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'name' => 'ACCION SOCIAL',
                'icon' => 'thumb_up',
                'color_icon' => 'light-green-A700-fg',
                'description' => 'PUBLICACIONES CORRESPONDIENTES AL TIPO DE CONTENIDOS ACCION SOCIAL',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
