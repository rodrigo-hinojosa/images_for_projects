<?php

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;

class CommunityStateTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        factory(App\CommunityState::class, 2)->create();

        DB::table('community_states')->insert([
            [
                'name' => 'ACTIVA',
                'icon' => 'check',
                'color_icon' => 'green-A700-fg',
                'description' => 'COMUNIDAD ACTIVA EN PRODUCCION',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'name' => 'INACTIVA',
                'icon' => 'close',
                'color_icon' => 'red-A700-fg',
                'description' => 'COMUNIDAD INACTIVA EN PRODUCCION',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
