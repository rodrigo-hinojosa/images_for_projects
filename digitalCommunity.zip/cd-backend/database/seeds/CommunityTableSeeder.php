<?php

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class CommunityTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        factory(App\Community::class, 10)->create();

        DB::table('communities')->insert([
            [
                'father_community_id' => 0,
                'community_state_id' => 1,
                'url' => 'http://www.trends.cl/',
                'url_back_office' => 'http://www.trends.cl/admin',
                'api_key' => Hash::make(1),
                'name' => 'TRENDS',
                'addres' => 'Evaristo Lillo #112',
                'phone' => '222064491',
                'image' => '',
                'email' => 'info@trends.cl',
                'description' => 'COMUNIDAD ADMINISTRADORA DEL SISTEMA',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 1,
                'community_state_id' => 1,
                'url' => 'http://comunidad-evangelica.web-service.cl/',
                'url_back_office' => 'http://comunidad-evangelica.web-service.cl/',
                'api_key' => Hash::make(2),
                'name' => 'Comunidad Evangèlica de Chile',
                'addres' => 'Los hermanos carrera #1142',
                'phone' => '222064491',
                'image' => '',
                'email' => 'info@comunidad-evangelica.cl',
                'description' => 'Comunidad Evangèlica de Chile descripcion',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 2,
                'community_state_id' => 1,
                'url' => 'http://iglesia1.web-service.cl/',
                'url_back_office' => 'http://iglesia1.web-service.cl/login',
                'api_key' => Hash::make(3),
                'name' => 'Iglesia 1',
                'addres' => 'Calle Iglesia1',
                'phone' => '111111111',
                'image' => '',
                'email' => 'info@Iglesia1.cl',
                'description' => 'Iglesia 1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 3,
                'community_state_id' => 1,
                'url' => 'http://pastorado11.web-service.cl/',
                'url_back_office' => 'http://pastorado11.web-service.cl/login',
                'api_key' => Hash::make(4),
                'name' => 'pastorado 1 1',
                'addres' => 'Calle pastorado11',
                'phone' => '222222222',
                'image' => '',
                'email' => 'info@pastorado11.cl',
                'description' => 'pastorado 1 1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 4,
                'community_state_id' => 1,
                'url' => 'http://templo111.web-service.cl/',
                'url_back_office' => 'http://templo111.web-service.cl/login',
                'api_key' => Hash::make(5),
                'name' => 'templo 1 1 1',
                'addres' => 'Calle templo111',
                'phone' => '333333333',
                'image' => '',
                'email' => 'info@templo111.cl',
                'description' => 'templo 1 1 1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 4,
                'community_state_id' => 1,
                'url' => 'http://templo112.web-service.cl/',
                'url_back_office' => 'http://templo112.web-service.cl/login',
                'api_key' => Hash::make(6),
                'name' => 'templo 1 1 2',
                'addres' => 'Calle templo112',
                'phone' => '444444444',
                'image' => '',
                'email' => 'info@templo112.cl',
                'description' => 'templo 1 1 2',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 3,
                'community_state_id' => 1,
                'url' => 'http://pastorado12.web-service.cl/',
                'url_back_office' => 'http://pastorado12.web-service.cl/login',
                'api_key' => Hash::make(7),
                'name' => 'pastorado 1 2',
                'addres' => 'Calle pastorado12',
                'phone' => '555555555',
                'image' => '',
                'email' => 'info@pastorado12.cl',
                'description' => 'pastorado 1 2',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 7,
                'community_state_id' => 1,
                'url' => 'http://templo121.web-service.cl/',
                'url_back_office' => 'http://templo121.web-service.cl/login',
                'api_key' => Hash::make(8),
                'name' => 'templo 1 2 1',
                'addres' => 'Calle templo121',
                'phone' => '666666666',
                'image' => '',
                'email' => 'info@templo121.cl',
                'description' => 'templo 1 2 1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 2,
                'community_state_id' => 1,
                'url' => 'http://Iglesia2.web-service.cl/',
                'url_back_office' => 'http://Iglesia2.web-service.cl/login',
                'api_key' => Hash::make(9),
                'name' => 'Iglesia 2',
                'addres' => 'Calle Iglesia2',
                'phone' => '777777777',
                'image' => '',
                'email' => 'info@Iglesia2.cl',
                'description' => 'Iglesia 2',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 9,
                'community_state_id' => 1,
                'url' => 'http://pastorado21.web-service.cl/',
                'url_back_office' => 'http://pastorado21.web-service.cl/login',
                'api_key' => Hash::make(10),
                'name' => 'pastorado 2 1',
                'addres' => 'Calle pastorado21',
                'phone' => '777777777',
                'image' => '',
                'email' => 'info@pastorado21.cl',
                'description' => 'pastorado 2 1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 10,
                'community_state_id' => 1,
                'url' => 'http://templo211.web-service.cl/',
                'url_back_office' => 'http://templo211.web-service.cl/login',
                'api_key' => Hash::make(11),
                'name' => 'templo 2 1 1',
                'addres' => 'Calle templo211',
                'phone' => '777777777',
                'image' => '',
                'email' => 'info@templo211.cl',
                'description' => 'templo 2 11',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 10,
                'community_state_id' => 1,
                'url' => 'http://templo212.web-service.cl/',
                'url_back_office' => 'http://templo212.web-service.cl/login',
                'api_key' => Hash::make(12),
                'name' => 'templo 2 1 2',
                'addres' => 'Calle templo212',
                'phone' => '777777777',
                'image' => '',
                'email' => 'info@templo212.cl',
                'description' => 'templo 2 1 2',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 9,
                'community_state_id' => 1,
                'url' => 'http://pastorado22.web-service.cl/',
                'url_back_office' => 'http://pastorado22.web-service.cl/login',
                'api_key' => Hash::make(13),
                'name' => 'pastorado 2 2',
                'addres' => 'Calle pastorado22',
                'phone' => '777777777',
                'image' => '',
                'email' => 'info@pastorado22.cl',
                'description' => 'pastorado 2 2',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'father_community_id' => 13,
                'community_state_id' => 1,
                'url' => 'http://templo221.web-service.cl/',
                'url_back_office' => 'http://templo221.web-service.cl/login',
                'api_key' => Hash::make(14),
                'name' => 'templo 2 2 1',
                'addres' => 'Calle templo221',
                'phone' => '777777777',
                'image' => '',
                'email' => 'info@templo221.cl',
                'description' => 'templo 2 2 1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
