<?php

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            [
                'user_type_id' => 1,
                'user_state_id' => 1,
                'name' => 'SYSTEM',
                'lastname' => '',
                'email' => 'system@trends.cl',
                'username' => 'system',
                'password' => Hash::make('pass'),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'user_type_id' => 1,
                'user_state_id' => 1,
                'name' => 'Rodrigo Andres',
                'lastname' => 'Hinojosa Acuña',
                'email' => 'rodrigo.hinojosa@trends.cl',
                'username' => 'rh',
                'password' => Hash::make('pass'),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);

        factory(App\User::class, 10)->create();
    }

}
