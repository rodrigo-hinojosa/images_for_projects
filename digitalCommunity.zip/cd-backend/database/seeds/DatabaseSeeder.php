<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            UserTypeTableSeeder::class,
            UserStateTableSeeder::class,
            ContentStateTableSeeder::class,
            CommunityStateTableSeeder::class,
            CommunityTableSeeder::class,
            ContentTypeTableSeeder::class,
            PageTableSeeder::class,
            FrameTableSeeder::class,
            ContentTableSeeder::class,
            UserTableSeeder::class,
//            DistributionTableSeeder::class,
            DetailTableSeeder::class,
            CommunityManagerTableSeeder::class
        ]);
    }

}
