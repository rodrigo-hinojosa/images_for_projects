<?php

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;

class FrameTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        factory(App\Frame::class, 30)->create();

        DB::table('frames')->insert([
            [
                'page_id' => 1,
                'content_type_id' => 1,
                'publicity_id' => 0,
                'identifier' => 'noticias-cd-comu1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 1,
                'content_type_id' => 2,
                'publicity_id' => 0,
                'identifier' => 'eventos-cd-comu1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 1,
                'content_type_id' => 3,
                'publicity_id' => 0,
                'identifier' => 'accion-cd-comu1',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 3,
                'content_type_id' => 1,
                'publicity_id' => 0,
                'identifier' => 'noticias-cd-comu2',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 3,
                'content_type_id' => 2,
                'publicity_id' => 0,
                'identifier' => 'eventos-cd-comu2',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 3,
                'content_type_id' => 3,
                'publicity_id' => 0,
                'identifier' => 'accion-cd-comu2',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 5,
                'content_type_id' => 1,
                'publicity_id' => 0,
                'identifier' => 'noticias-cd-comu3',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 5,
                'content_type_id' => 2,
                'publicity_id' => 0,
                'identifier' => 'eventos-cd-comu3',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 5,
                'content_type_id' => 3,
                'publicity_id' => 0,
                'identifier' => 'accion-cd-comu3',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 7,
                'content_type_id' => 1,
                'publicity_id' => 0,
                'identifier' => 'noticias-cd-comu4',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 7,
                'content_type_id' => 2,
                'publicity_id' => 0,
                'identifier' => 'eventos-cd-comu4',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 7,
                'content_type_id' => 3,
                'publicity_id' => 0,
                'identifier' => 'accion-cd-comu4',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 9,
                'content_type_id' => 1,
                'publicity_id' => 0,
                'identifier' => 'noticias-cd-comu5',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 9,
                'content_type_id' => 2,
                'publicity_id' => 0,
                'identifier' => 'eventos-cd-comu5',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 9,
                'content_type_id' => 3,
                'publicity_id' => 0,
                'identifier' => 'accion-cd-comu5',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 11,
                'content_type_id' => 1,
                'publicity_id' => 0,
                'identifier' => 'noticias-cd-comu6',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 11,
                'content_type_id' => 2,
                'publicity_id' => 0,
                'identifier' => 'eventos-cd-comu6',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'page_id' => 11,
                'content_type_id' => 3,
                'publicity_id' => 0,
                'identifier' => 'accion-cd-comu6',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
