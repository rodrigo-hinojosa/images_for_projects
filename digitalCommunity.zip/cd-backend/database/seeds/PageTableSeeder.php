<?php

use Illuminate\Support\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class PageTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        factory(App\Page::class, 10)->create();

        DB::table('pages')->insert([
            [
                'community_id' => 2,
                'name' => 'index',
                'url' => 'http://comunidad-evangelica.web-service.cl/index.html',
                'api_key' => Hash::make(1),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 2,
                'name' => 'detail',
                'url' => 'http://comunidad-evangelica.web-service.cl/contenido.html',
                'api_key' => Hash::make(2),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 3,
                'name' => 'index',
                'url' => 'http://iglesia1.web-service.cl/index.php',
                'api_key' => Hash::make(3),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 3,
                'name' => 'detail',
                'url' => 'http://iglesia1.web-service.cl/contenido',
                'api_key' => Hash::make(4),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 4,
                'name' => 'index',
                'url' => 'http://pastorado11.web-service.cl/index.html',
                'api_key' => Hash::make(5),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 4,
                'name' => 'detail',
                'url' => 'http://pastorado11.web-service.cl/contenido.html',
                'api_key' => Hash::make(6),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 5,
                'name' => 'index',
                'url' => 'http://templo111.web-service.cl/index.php',
                'api_key' => Hash::make(7),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 5,
                'name' => 'detail',
                'url' => 'http://templo111.web-service.cl/contenido',
                'api_key' => Hash::make(8),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 6,
                'name' => 'index',
                'url' => 'http://templo112.web-service.cl/index.html',
                'api_key' => Hash::make(9),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 6,
                'name' => 'detail',
                'url' => 'http://templo112.web-service.cl/contenido.html',
                'api_key' => Hash::make(10),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 7,
                'name' => 'index',
                'url' => 'http://pastorado12.web-service.cl/index.php',
                'api_key' => Hash::make(11),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 7,
                'name' => 'detail',
                'url' => 'http://pastorado12.web-service.cl/contenido',
                'api_key' => Hash::make(12),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 8,
                'name' => 'index',
                'url' => 'http://templo121.web-service.cl/index.php',
                'api_key' => Hash::make(13),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 8,
                'name' => 'detail',
                'url' => 'http://templo121.web-service.cl/contenido',
                'api_key' => Hash::make(14),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 9,
                'name' => 'index',
                'url' => 'http://Iglesia2.web-service.cl/index.html',
                'api_key' => Hash::make(15),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 9,
                'name' => 'detail',
                'url' => 'http://Iglesia2.web-service.cl/contenido.html',
                'api_key' => Hash::make(16),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 10,
                'name' => 'index',
                'url' => 'http://pastorado21.web-service.cl/index.php',
                'api_key' => Hash::make(17),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 10,
                'name' => 'detail',
                'url' => 'http://pastorado21.web-service.cl/contenido',
                'api_key' => Hash::make(18),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 11,
                'name' => 'index',
                'url' => 'http://templo211.web-service.cl/index.html',
                'api_key' => Hash::make(19),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 11,
                'name' => 'detail',
                'url' => 'http://templo211.web-service.cl/contenido.html',
                'api_key' => Hash::make(20),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 12,
                'name' => 'index',
                'url' => 'http://templo212.web-service.cl/index.php',
                'api_key' => Hash::make(21),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 12,
                'name' => 'detail',
                'url' => 'http://templo212.web-service.cl/contenido',
                'api_key' => Hash::make(22),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 13,
                'name' => 'index',
                'url' => 'http://pastorado22.web-service.cl/index.html',
                'api_key' => Hash::make(23),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 13,
                'name' => 'detail',
                'url' => 'http://pastorado22.web-service.cl/contenido.html',
                'api_key' => Hash::make(24),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 14,
                'name' => 'index',
                'url' => 'http://templo221.web-service.cl/index.html',
                'api_key' => Hash::make(25),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ],
            [
                'community_id' => 14,
                'name' => 'detail',
                'url' => 'http://templo221.web-service.cl/contenido.html',
                'api_key' => Hash::make(26),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]
        ]);
    }
}
