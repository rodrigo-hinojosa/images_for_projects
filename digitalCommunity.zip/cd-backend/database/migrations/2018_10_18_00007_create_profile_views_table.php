<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProfileViewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('profile_views', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->smallInteger('profile_id')->unsigned();
            $table->smallInteger('view_id')->unsigned();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::table('profile_views', function ($table) {
            $table->foreign('profile_id')->references('id')->on('profiles');
            $table->foreign('view_id')->references('id')->on('views');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('profile_views');
    }
}
