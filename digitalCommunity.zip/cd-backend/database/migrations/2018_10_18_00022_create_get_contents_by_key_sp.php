<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Migrations\Migration;

class CreateGetContentsByKeySp extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS get_contents_by_key; CREATE PROCEDURE get_contents_by_key(IN page_key varchar(60)) BEGIN DECLARE _community_id INT; DECLARE _page_id INT; SELECT pages.id, pages.community_id INTO _page_id, _community_id FROM pages WHERE pages.api_key = page_key; SELECT contents.id, (SELECT frames.identifier FROM frames WHERE frames.page_id = _page_id AND frames.content_type_id = contents.content_type_id AND frames.deleted_at IS NULL) AS identifier, contents.title, contents.content, contents.url_content AS urlContent, contents.url_image_content AS urlImageContent, contents.created_at AS createdAt, contents.updated_at AS updatedAt FROM contents WHERE deleted_at IS NULL AND contents.content_type_id IN (SELECT content_types.id FROM content_types WHERE content_types.id IN (SELECT frames.content_type_id FROM frames WHERE frames.page_id = _page_id AND frames.deleted_at IS NULL)) AND contents.id IN (SELECT distributions.content_id FROM distributions WHERE distributions.community_id = _community_id AND distributions.deleted_at IS NULL) ORDER BY contents.content_type_id, contents.id; END;');
    }
}
