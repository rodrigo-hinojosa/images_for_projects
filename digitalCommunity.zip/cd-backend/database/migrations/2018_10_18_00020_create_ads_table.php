<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ads', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->bigIncrements('id');
            $table->smallInteger('ads_space_id')->unsigned();
            $table->smallInteger('content_state_id')->unsigned();
            $table->integer('community_id')->unsigned();
            $table->bigInteger('content_inner_id');
            $table->text('title')->nullable();
            $table->longText('content')->nullable();
            $table->text('url_content');
            $table->bigInteger('image_content_id')->nullable();
            $table->text('url_image_content')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::table('ads', function ($table) {
            $table->foreign('ads_space_id')->references('id')->on('ads_spaces');
            $table->foreign('content_state_id')->references('id')->on('content_states');
            $table->foreign('community_id')->references('id')->on('communities');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('ads');
    }
}
