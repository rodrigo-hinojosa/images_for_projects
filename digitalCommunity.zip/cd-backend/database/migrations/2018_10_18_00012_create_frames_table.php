<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFramesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('frames', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->integer('page_id')->unsigned();
            $table->smallInteger('content_type_id')->unsigned();
            $table->integer('publicity_id')->unsigned();
            $table->string('identifier', 50);
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::table('frames', function ($table) {
            $table->foreign('page_id')->references('id')->on('pages');
            $table->foreign('content_type_id')->references('id')->on('content_types');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('frames');
    }
}
