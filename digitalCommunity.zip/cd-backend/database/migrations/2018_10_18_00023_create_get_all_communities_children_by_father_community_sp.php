<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Migrations\Migration;

class CreateGetAllCommunitiesChildrenByFatherCommunitySp extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS get_all_communities_children_by_father_community; CREATE PROCEDURE get_all_communities_children_by_father_community(IN _community_id int) BEGIN SELECT id, name, father_community_id as fatherCommunityId FROM `communities` WHERE id = _community_id UNION SELECT id, name, father_community_id as fatherCommunityId FROM `communities` WHERE FIND_IN_SET(`ID`, (SELECT GROUP_CONCAT(Level SEPARATOR \',\') FROM (SELECT @Ids := (SELECT GROUP_CONCAT(`id` SEPARATOR \',\') FROM `communities` WHERE FIND_IN_SET(`father_community_id`, @Ids)) Level FROM `communities` JOIN (SELECT @Ids := _community_id) temp1) temp2)) ORDER BY id; END;');
    }
}
