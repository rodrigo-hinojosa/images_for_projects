<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCommunitiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('communities', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->integer('father_community_id');
            $table->smallInteger('community_state_id')->unsigned();
            $table->string('url', 255);
            $table->string('url_back_office', 255);
            $table->string('api_key', 60);
            $table->string('name', 100);
            $table->string('addres', 100)->nullable();
            $table->string('phone', 100)->nullable();
            $table->text('image')->nullable();
            $table->string('email', 100)->nullable();
            $table->string('description', 2000)->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->unique(['url', 'deleted_at']);
            $table->unique(['url_back_office', 'deleted_at']);
            $table->unique(['name', 'deleted_at']);
        });

        Schema::table('communities', function ($table) {
            $table->foreign('community_state_id')->references('id')->on('community_states');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('communities');
    }
}
