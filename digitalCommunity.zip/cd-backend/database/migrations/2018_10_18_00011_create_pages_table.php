<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pages', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->integer('community_id')->unsigned();
            $table->string('name', 100);
            $table->string('url', 255);
            $table->string('api_key', 60);
            $table->timestamps();
            $table->softDeletes();

            $table->unique(['url', 'deleted_at']);
            $table->unique(['api_key', 'deleted_at']);
        });

        Schema::table('pages', function ($table) {
            $table->foreign('community_id')->references('id')->on('communities');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('pages');
    }
}
