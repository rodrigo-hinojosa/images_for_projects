<?php

use Faker\Generator as Faker;

$factory->define(App\Page::class, function (Faker $faker) {

    $url = $faker->unique()->url;

    return [
        'community_id' => App\Community::all()->random()->id,
        'name' => $faker->unique()->name,
        'url' => $url,
        'api_key' => $url,
    ];

});