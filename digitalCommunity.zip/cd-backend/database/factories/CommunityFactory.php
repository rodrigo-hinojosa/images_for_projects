<?php

use Faker\Generator as Faker;

$factory->define(App\Community::class, function (Faker $faker) {

    return [
        'father_community_id' => 1,
        'community_state_id' => App\CommunityState::all()->random()->id,
        'url' => 'http://www.' . $faker->domainName,
        'name' => $faker->name,
        'addres' => str_replace(',', '', $faker->address),
        'phone' => rand(60000000, 99999999),
        'image' => $faker->url,
        'email' => $faker->unique()->email,
        'description' => $faker->text,
    ];

});