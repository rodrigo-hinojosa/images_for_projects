<?php

use Faker\Generator as Faker;

$factory->define(App\Distribution::class, function (Faker $faker) {

    return [
        'content_id' => App\Content::all()->random()->id,
        'community_id' => App\Community::all()->random()->id,
        'user_id' => App\User::all()->random()->id,
    ];

});