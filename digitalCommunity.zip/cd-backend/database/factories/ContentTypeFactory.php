<?php

use Faker\Generator as Faker;

$factory->define(App\ContentType::class, function (Faker $faker) {

    return [
        'content_type_wp_id' => rand(1, 5),
        'name' => $faker->unique()->name,
        'icon' => $faker->text,
        'color_icon' => $faker->colorName,
        'description' => $faker->text,
    ];

});