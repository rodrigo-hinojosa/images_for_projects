<?php

use Faker\Generator as Faker;

$factory->define(App\Frame::class, function (Faker $faker) {

    return [
        'page_id' => App\Page::all()->random()->id,
        'content_type_id' => App\ContentType::all()->random()->id,
        'publicity_id' => 0,
        'identifier' => $faker->randomDigit,
    ];

});