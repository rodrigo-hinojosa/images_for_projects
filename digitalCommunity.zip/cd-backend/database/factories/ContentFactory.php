<?php

use Faker\Generator as Faker;

$factory->define(App\Content::class, function (Faker $faker) {

    return [
        'content_type_id' => App\ContentType::all()->random()->id,
        'content_state_id' => App\ContentState::all()->random()->id,
        'community_id' => App\Community::all()->random()->id,
        'content_inner_id' => $faker->randomDigit,
        'title' => $faker->streetName,
        'content' => $faker->text,
        'url_content' => $faker->unique()->url,
        'image_content_id' => $faker->randomDigit,
        'url_image_content' => $faker->unique()->url,
    ];

});