<?php

namespace App\Transformer;

use League\Fractal\TransformerAbstract;

class OutPutDataTransformer extends TransformerAbstract
{
    public function transform($data, $separator = '_')
    {
        if (!is_null($data)) :

            foreach ($data->toArray() as $property => $value) {

                if (is_array($value)) :

                    $outPutData2 = [];

                    foreach ($value as $property2 => $value2) {

                        foreach ($value2 as $property3 => $value3) {

                            $camelCase3 = str_replace($separator, '', lcfirst(ucwords($property3, $separator)));

                            $outPutData3[$camelCase3] = $value3;

                        }

                        $outPutData2[$property2] = $outPutData3;

                    }

                    $value = $outPutData2;

                endif;

                $camelCase = str_replace($separator, '', lcfirst(ucwords($property, $separator)));

                $outPutData[$camelCase] = $value;
            }

            return $outPutData;
        else :
            return [];
        endif;
    }
}
