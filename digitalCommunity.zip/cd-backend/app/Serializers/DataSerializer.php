<?php

namespace App\Serializers;

use League\Fractal\Serializer\ArraySerializer;

class DataSerializer extends ArraySerializer
{
    public function collection($resourceKey, array $data)
    {
        if ($resourceKey) :
            return [$resourceKey => $data];
        else :
            return $data;
        endif;
    }

    public function item($resourceKey, array $data)
    {
        if ($resourceKey) :
            return [$resourceKey => $data];
        else :
            return $data;
        endif;
    }
}