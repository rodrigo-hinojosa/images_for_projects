<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Page extends Model
{
    use SoftDeletes;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'community_id',
        'name',
        'url',
        'api_key'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    /**
     * Relationship with Community model
     */
    public function community()
    {
        return $this->belongsTo(Community::class);
    }

    /**
     * Relationship with Frame model
     */
    public function frames()
    {
        return $this->hasMany(Frame::class);
    }

    /**
     * Relationship with Detail model
     */
    public function detail()
    {
        return $this->hasOne(Detail::class);
    }
}
