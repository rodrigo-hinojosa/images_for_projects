<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Community extends Model
{
    use SoftDeletes;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */

    protected $dates = ['deleted_at'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'father_community_id',
        'community_state_id',
        'url',
        'url_back_office',
        'api_key',
        'api_key',
        'name',
        'addres',
        'phone',
        'image',
        'email',
        'description'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    /**
     * Relationship with CommunityState model
     */
    public function communityState()
    {
        return $this->belongsTo(CommunityState::class);
    }

    /**
     * Relationship with Content model
     */
    public function contents()
    {
        return $this->hasMany(Content::class);
    }

    /**
     * Relationship with Page model
     */
    public function pages()
    {
        return $this->hasMany(Page::class);
    }

    /**
     * Relationship with Distribution model
     */
    public function distributions()
    {
        return $this->hasMany(Distribution::class);
    }
}
