<?php

namespace App\Services;

use App\User;
use App\Repositories\Repository;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class UserService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $userInPutDataTransformer;
    protected $userOutPutDataTransformer;

    public function __construct(User $user,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $userInPutDataTransformer,
                                OutPutDataTransformer $userOutPutDataTransformer)
    {
        $this->repository = new Repository($user);
        $this->dataTransformer = $dataTransformer;
        $this->userInPutDataTransformer = $userInPutDataTransformer;
        $this->userOutPutDataTransformer = $userOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->with('communityManagers')->get(['id', 'name', 'lastname', 'email']),
            $this->userOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->userInPutDataTransformer);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->create($resource),
                $this->userOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->with('communityManagers')->find($id),
            $this->userOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->userInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->userOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        /**
         * Check if User have relationship with other model (can´t remove if exist)
         *
         */
        if ($this->repository->with('distributions')->find($id)->distributions->first()) :
            return response()->json(
                ['integrity_reference' => true]
                , 400
            );
        else :
            return $this->dataTransformer->itemDataTransformer(
                $this->repository->delete($id),
                $this->userOutPutDataTransformer
            );
        endif;
    }

    /**
     * Return user asociated to token
     *
     * @return app('auth')->guard()->user()
     */
    public function getUserByAccessTokenService()
    {
        $user = app('auth')->guard()->user();

        $communityToManager = DB::table('community_managers as cm')->select(
            'cm.id as id',
            'cm.status as status',
            'c.id as communityId',
            'c.name as communityName',
            'c.url_back_office as communityUrlBackOffice')
            ->join('communities as c', 'c.id', '=', 'cm.community_id')
            ->where('cm.user_id', $user->id)
            ->whereNull('cm.deleted_at')
            ->whereNull('c.deleted_at')
            ->get();

        $userData = (object)[
//            'id' => Crypt::encryptString($user->id),
            'id' => $user->id,
            'name' => $user->name,
            'lastname' => $user->lastname,
            'username' => $user->username,
            'email' => $user->email,
            'communityManagers' => $communityToManager
        ];

        return response()->json(
            $userData
        );
    }

    public function updateCurrentPasswordService($data, $id)
    {
        $pass = DB::table('users')
            ->where('id', $id)
            ->value('password');

        if ($pass):

            if (Hash::check($data['currentPassword'], $pass)) :

                return $this->updateService($data, $id);

            else :

                return response()->json(
                    ['password' => ['incorrect password']]
                    , 422
                );

            endif;


        else:

            return response()->json(
                ['message' => 'resource not found']
                , 404
            );

        endif;
    }
}
