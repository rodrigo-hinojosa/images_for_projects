<?php

namespace App\Services;

use App\Frame;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class FrameService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $frameOutPutDataTransformer;
    protected $frameInPutDataTransformer;

    public function __construct(Frame $frame,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $frameInPutDataTransformer,
                                OutPutDataTransformer $frameOutPutDataTransformer)
    {
        $this->repository = new Repository($frame);
        $this->dataTransformer = $dataTransformer;
        $this->frameInPutDataTransformer = $frameInPutDataTransformer;
        $this->frameOutPutDataTransformer = $frameOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*']),
            $this->frameOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->frameInPutDataTransformer);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->create($resource),
                $this->frameOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->frameOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->frameInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->frameOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->delete($id),
            $this->frameOutPutDataTransformer
        );
    }

    /**
     * Display a listing of the resource by relation with other model.
     *
     * @return \App\Repositories\Repository@all
     */
    public function getFramesByPageService($id)
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*'])->where('page_id', $id),
            $this->frameOutPutDataTransformer
        );
    }
}