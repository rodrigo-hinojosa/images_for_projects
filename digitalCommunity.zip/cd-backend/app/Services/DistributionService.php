<?php

namespace App\Services;

use App\Distribution;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class DistributionService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $distributionOutPutDataTransformer;
    protected $distributionInPutDataTransformer;

    public function __construct(Distribution $distribution,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $distributionInPutDataTransformer,
                                OutPutDataTransformer $distributionOutPutDataTransformer)
    {
        $this->repository = new Repository($distribution);
        $this->dataTransformer = $dataTransformer;
        $this->distributionInPutDataTransformer = $distributionInPutDataTransformer;
        $this->distributionOutPutDataTransformer = $distributionOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*']),
            $this->distributionOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function innerStoreService($data)
    {

        return $this->repository->create($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {

        $resource = $this->dataTransformer->itemDataTransformer($data, $this->distributionInPutDataTransformer);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->create($resource),
                $this->distributionOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->distributionOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->distributionInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->distributionOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->delete($id),
            $this->distributionOutPutDataTransformer
        );
    }
}