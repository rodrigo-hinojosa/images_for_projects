<?php

namespace App\Services;

use App\Content;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ContentService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $contentOutPutDataTransformer;
    protected $contentInPutDataTransformer;

    protected $distributionService;

    public function __construct(Content $content,
                                DistributionService $distributionService,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $contentInPutDataTransformer,
                                OutPutDataTransformer $contentOutPutDataTransformer)
    {
        $this->repository = new Repository($content);
        $this->dataTransformer = $dataTransformer;
        $this->contentInPutDataTransformer = $contentInPutDataTransformer;
        $this->contentOutPutDataTransformer = $contentOutPutDataTransformer;

        $this->distributionService = $distributionService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return object \App\Repositories\Repository@all
     */
    public function indexService()
    {
//        return $this->dataTransformer->collectionDataTransformer(
//            $this->repository->all(['*']),
//            $this->contentOutPutDataTransformer
//        );
        return DB::table('contents')->select(
            'contents.id',
            'communities.name as communityName',
            'contents.content_type_id as contentTypeId',
            'contents.title',
            'contents.content',
            'pages.url as urlContent',
            'contents.url_image_content as urlImageContent',
            'contents.updated_at as updatedAt')
            ->join('communities', 'communities.id', '=', 'contents.community_id')
            ->join('pages', 'pages.community_id', '=', 'communities.id')
            ->join('details', 'details.page_id', '=', 'pages.id')
            ->whereNull('contents.deleted_at')
            ->orderBy('contents.updated_at', 'desc')
            ->paginate(12);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->contentInPutDataTransformer);

        $newContent = $this->repository->create($resource);

        $newDistribution = [
            'content_id' => $newContent->id,
            'community_id' => $newContent->community_id,
            'user_id' => 1
        ];

        if ($this->distributionService->innerStoreService($newDistribution)) :

            return response()->json(
                $this->dataTransformer->itemDataTransformer(
                    $newContent,
                    $this->contentOutPutDataTransformer),
                201
            );

        else:

            return response()->json(
                null
                , 422
            );

        endif;

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return object \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->contentOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return object \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->contentInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->contentOutPutDataTransformer
        );
    }

    /**
     * Exec updateService
     *
     * @param  array $data
     * @param  int $idInnerContent
     * @param  int $idCommunity
     *
     * @return object @DB::table
     */
    public function updateContentIdByInnerContentService($data, $idInnerContent, $idCommunity)
    {
        $idContent = $this->getContentIdByInnerContentService($idInnerContent, $idCommunity);

        if ($idContent) :

            return $this->updateService($data, $idContent);

        else :

            return response()->json(
                null
                , 404
            );

        endif;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return object \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
//        /**
//         * Check if Content have relationship with other model (can´t remove if exist)
//         *
//         */
//        if ($this->repository->with('distributions')->find($id)->distributions->first()) :
//            return response()->json(
//                ['integrity_reference' => true]
//                , 400
//            );
//        else :
//            return $this->dataTransformer->itemDataTransformer(
//                $this->repository->delete($id),
//                $this->contentOutPutDataTransformer
//            );
//        endif;

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->delete($id),
            $this->contentOutPutDataTransformer
        );
    }

    /**
     * Exec destroyService
     *
     * @param  int $idInnerContent
     * @param  int $idCommunity
     *
     * @return object @DB::table
     */
    public function destroyContentIdByInnerContentService($idInnerContent, $idCommunity)
    {
        $idContent = $this->getContentIdByInnerContentService($idInnerContent, $idCommunity);

        if ($idContent) :

            return $this->destroyService($idContent);

        else :

            return response()->json(
                null
                , 404
            );

        endif;
    }

    /**
     * Exec destroyService
     *
     * @param  int $idInnerContent
     * @param  int $idCommunity
     *
     * @return object @DB::table
     */
    public function restoreContentIdByInnerContentService($idInnerContent, $idCommunity)
    {
        $idContent = $this->getContentIdByInnerContentService($idInnerContent, $idCommunity);

        if ($idContent) :

            $content = Content::withTrashed()->find($idContent);

            $content->restore();

            return $content;

        else :

            return response()->json(
                null
                , 404
            );

        endif;
    }

    /**
     * Get Content detail by ID Content
     *
     * @param  string $key
     * @param  string $domain
     * @param  int $idContent
     *
     * @return object response()->json()
     */
    public function apiDetailContentsService($key, $domain, $idContent)
    {
        $page = $this->getPageByKeyToCheckService($key);

        if (Hash::check($page->id, $key) && $this->getCommunityByIdToCheckService($page->community_id, $domain)) :

            try {

                return response()->json(
                    ['content' => $this->showService($idContent),
                        'identifier' => $this->getDetailIdentifierByPageService($page->id)]
                    , 200
                );

            } catch (ModelNotFoundException $exception) {

                return response()->json(
                    ['identifier' => $this->getDetailIdentifierByPageService($page->id)]
                    , 404
                );

            }

        else:

            return response()->json(
                ['response' => 'unauthorized']
                , 401
            );

        endif;

    }

    /**
     * Get Contents index by community page
     *
     * @param  object $request
     *
     * @return object response()->json()
     */
    public function apiIndexContentsService($request)
    {
        $page = $this->getPageByKeyToCheckService($request->key);

        if (Hash::check($page->id, $request->key) && $this->getCommunityByIdToCheckService($page->community_id, $request->domain)) :

            $frames = [];

            foreach ($this->getContentTypeIdsByPageService($page->id)->toArray() as $contentType) {

                $frame = $this->getFramesIdentifiersByPageService($page->id, $contentType->content_type_id);

                $frame[0]->contents = $this->getDistributedContentByCommunityService($page->community_id, $contentType->content_type_id, 4);

                array_push($frames, $frame[0]);

            }

            return response()->json(
                [
                    'frames' => $frames,
                    'urlDetail' => $this->getUrlDetailByPageService($page->id)
                ]
                , 200
            );

        else:
            return response()->json(
                ['response' => 'unauthorized']
                , 401
            );
        endif;
    }

    /**
     * Get Contents pagination index by community page
     *
     * @param  object $request
     *
     * @return object response()->json()
     */
    public function apiIndexContentsByPaginationService($request)
    {
        $page = $this->getPageByKeyToCheckService($request->key);

        if (Hash::check($page->id, $request->key) && $this->getCommunityByIdToCheckService($page->community_id, $request->domain)) :

            return response()->json(
                $this->getDistributedContentByCommunityService($page->community_id, $request->contentTypeId, 4)
                , 200
            );


        else:
            return response()->json(
                ['response' => 'unauthorized']
                , 401
            );
        endif;
    }

    /**
     * Get Contents By Distribution
     *
     * @param  App\Http\Requests\ContentRequestGetContentAssociated
     * @return @DB::getContentsByCommunityAndContentTypesService
     */
    public function getContentsByCommunityAndContentTypesService($contentRequestGetContentAssociated)
    {
        $idCommunity = $contentRequestGetContentAssociated->idCommunity;

        $contentTypes = array_map('intval', explode(',', $contentRequestGetContentAssociated->contentTypesIds));

        $totalContents = $contentRequestGetContentAssociated->totalCount;

        return DB::table('contents')->select(
            'contents.id',
            'communities.name as communityName',
            'contents.content_type_id as contentTypeId',
            'contents.title',
            'contents.content',
            'contents.url_content as urlContent',
            'contents.url_image_content as urlImageContent',
            'contents.updated_at as updatedAt',
            'distributions.id as idDistribution',
            DB::raw('1 as distributionStatus, true as filterStatus'))
            ->join('communities', 'communities.id', '=', 'contents.community_id')
            ->join('distributions', 'contents.id', '=', 'distributions.content_id')
            ->whereIn('contents.content_type_id', $contentTypes)
            ->where('distributions.community_id', $idCommunity)
            ->whereNull('distributions.deleted_at')
            ->paginate($totalContents);
    }

    /**
     * Get Contents For Distribution
     *
     * @param  App\Http\Requests\ContentRequestGetContentNotAssociated
     * @return @DB::getContentsByNotCommunityAndContentTypesService
     */
    public function getContentsByNotCommunityAndContentTypesService($contentRequestGetContentNotAssociated)
    {
        $contentId = $contentRequestGetContentNotAssociated->contentId;

        $idCommunity = $contentRequestGetContentNotAssociated->idCommunity;

        $communities = array_map('intval', explode(',', $contentRequestGetContentNotAssociated->communities));

        $contentTypes = array_map('intval', explode(',', $contentRequestGetContentNotAssociated->contentTypesIds));

        $datesRange = [$contentRequestGetContentNotAssociated->dateStart, $contentRequestGetContentNotAssociated->dateEnd];

        $totalContents = $contentRequestGetContentNotAssociated->totalCount;

        return DB::table('contents')->select(
            'contents.id',
            'communities.name as communityName',
            'contents.content_type_id as contentTypeId',
            'contents.title',
            'contents.content',
            'pages.url as urlContent',
            'contents.url_image_content as urlImageContent',
            'contents.updated_at as updatedAt',
            DB::raw('0 as distributionStatus, true as filterStatus'))
            ->join('communities', 'communities.id', '=', 'contents.community_id')
            ->join('pages', 'pages.community_id', '=', 'communities.id')
            ->join('details', 'details.page_id', '=', 'pages.id')
            ->whereIn('contents.content_type_id', $contentTypes)
            ->whereIn('communities.id', $communities)
            ->whereNull('contents.deleted_at')
            ->whereBetween(DB::raw('date(contents.updated_at)'), $datesRange)
            ->whereNotExists(function ($query) use ($idCommunity) {
                $query->select('content_id')
                    ->from('distributions')
                    ->whereRaw('distributions.content_id = contents.id')
                    ->whereRaw('distributions.community_id = ' . $idCommunity)
                    ->whereRaw('distributions.deleted_at IS NULL');
            })
            ->orWhere('contents.id', '=', $contentId)
            ->paginate($totalContents);
    }

    /**
     * Get Content ID BY Inner ID and Community ID
     *
     * @param  int $idInnerContent
     * @param  int $idCommunity
     *
     * @return int @DB::table
     */
    public function getContentIdByInnerContentService($idInnerContent, $idCommunity)
    {
        return DB::table('contents')
            ->where([
                ['content_inner_id', $idInnerContent], ['community_id', $idCommunity]
            ])->value('id');
    }

    /**
     * Get Page Detail identifier by community id
     *
     * @param  int $page_id
     * @return @DB::table
     */
    public function getUrlDetailByPageService($page_id)
    {
        return DB::table('pages')
            ->where('pages.community_id', $page_id)
            ->join('details', 'pages.id', '=', 'details.page_id')
            ->value('url');
    }

    /**
     * Get Detail identifier by page id
     *
     * @param  int $pageId
     * @return @DB::table
     */
    private function getDetailIdentifierByPageService($pageId)
    {
        return DB::table('details')
            ->select('identifier')
            ->where('page_id', $pageId)
            ->whereNull('deleted_at')->get();
    }

    /**
     * Get Frames identifier by page id
     *
     * @param  int $pageId
     * @param  int $contentType
     *
     * @return @DB::table
     */
    private function getFramesIdentifiersByPageService($pageId, $contentType)
    {
        return DB::table('frames')
            ->select('content_types.id', 'content_types.name', 'frames.identifier')
            ->join('content_types', 'content_types.id', '=', 'frames.content_type_id')
            ->where('frames.page_id', $pageId)
            ->where('content_types.id', $contentType)
            ->whereNull('frames.deleted_at')
            ->get();
    }

    /**
     * Get Content Types associated to page
     *
     * @param  int $pageId
     *
     * @return @DB::table
     */
    private function getContentTypeIdsByPageService($pageId)
    {
        return DB::table('frames')
            ->select('content_type_id')
            ->where('frames.page_id', $pageId)
            ->whereNull('frames.deleted_at')
            ->get();
    }

    /**
     * Get Frames identifier by page id
     *
     * @param  int $communityId
     * @param  int $contentType
     * @param  int $quantity
     *
     * @return @DB::table
     */
    private function getDistributedContentByCommunityService($communityId, $contentType, $quantity = 6)
    {
        return DB::table('contents')->select(
            'contents.id',
            'contents.content_type_id as contentTypeId',
            'contents.title',
            'contents.content',
            'contents.url_content as urlContent',
            'contents.url_image_content as urlImageContent',
            'contents.updated_at as updatedAt')
            ->join('distributions', 'contents.id', '=', 'distributions.content_id')
            ->where('contents.content_type_id', $contentType)
            ->whereNull('contents.deleted_at')
            ->where('distributions.community_id', $communityId)
            ->whereNull('distributions.deleted_at')
            ->orderBy('contents.updated_at', 'DESC')
            ->paginate($quantity);
    }

    /**
     *  get page data by key
     *
     * @param  string $key
     * @return @DB::table
     */
    private function getPageByKeyToCheckService($key)
    {
        return DB::table('pages')
            ->select('id', 'community_id')
            ->where('api_key', $key)
            ->first();
    }

    /**
     * Check if community domain It's associated to some community
     *
     * @param  int $idCommunity
     * @param  string $domain
     * @return @DB::table
     */
    private function getCommunityByIdToCheckService($idCommunity, $domain)
    {
        $httpProtocol = ['http://', 'https://'];

        if (substr($domain, -1) !== '/') :

            $domain = $domain . '/';

        endif;

        $url = str_replace($httpProtocol, null, DB::table('communities')->where('id', $idCommunity)->value('url'));

        if (strtoupper($url) === strtoupper($domain)) :
            return true;
        endif;
    }
}

