<?php

namespace App\Services;

interface ServiceInterface
{
    public function indexService();

    public function destroyService($id);

    public function showService($id);

    public function storeService($data);

    public function updateService($data, $id);
}