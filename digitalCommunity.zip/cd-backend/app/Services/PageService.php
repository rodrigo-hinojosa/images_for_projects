<?php

namespace App\Services;

use App\Page;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;
use Illuminate\Support\Facades\Hash;

class PageService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $pageOutPutDataTransformer;
    protected $pageInPutDataTransformer;

    public function __construct(Page $page,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $pageInPutDataTransformer,
                                OutPutDataTransformer $pageOutPutDataTransformer)
    {
        $this->repository = new Repository($page);
        $this->dataTransformer = $dataTransformer;
        $this->pageInPutDataTransformer = $pageInPutDataTransformer;
        $this->pageOutPutDataTransformer = $pageOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*']),
            $this->pageOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@modify
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->pageInPutDataTransformer);

        $newPage = $this->repository->create($resource);

        $newPage['api_key'] = Hash::make($newPage->id);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->modify($newPage->toArray(), $newPage->id),
                $this->pageOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->pageOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->pageInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->pageOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        /**
         * Check if Page have relationship with other model (can´t remove if exist)
         *
         */
        if ($this->repository->with('frames')->find($id)->frames->first()) :
            return response()->json(
                ['integrity_reference' => true]
                , 400
            );
        else :
            return $this->dataTransformer->itemDataTransformer(
                $this->repository->delete($id),
                $this->pageOutPutDataTransformer
            );
        endif;
    }

    /**
     * Display a listing of the resource by relation with other model.
     *
     * @return \App\Repositories\Repository@all
     */
    public function getDetailByPageService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->with('detail')->find($id)->detail,
            $this->pageOutPutDataTransformer
        );
    }

    /**
     * Display a JSON response with boolean check by URL page
     *
     * @return String
     */
    public function checkIfUrlPageExistsService($url)
    {
        if ($this->isUrlAvailable($url)) :
            return response()->json(
                ['isUrlAvailable' => true]
                , 200
            );
        else :
            return response()->json(
                ['isUrlAvailable' => false]
                , 200
            );
        endif;
    }

    /**
     * Return TRUE is domain its availible
     *
     * @return Boolean
     */
    private function isUrlAvailable($url)
    {
//        $file_headers = @get_headers($url);
//
//        if (!$file_headers || $file_headers[0] == 'HTTP/1.1 404 Not Found') :
//            return false;
//        else :
//            return true;
//        endif;
        return true;
    }
}