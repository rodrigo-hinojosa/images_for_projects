<?php

namespace App\Services;

use App\Detail;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class DetailService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $detailOutPutDataTransformer;
    protected $detailInPutDataTransformer;

    public function __construct(Detail $detail,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $detailInPutDataTransformer,
                                OutPutDataTransformer $detailOutPutDataTransformer)
    {
        $this->repository = new Repository($detail);
        $this->dataTransformer = $dataTransformer;
        $this->detailInPutDataTransformer = $detailInPutDataTransformer;
        $this->detailOutPutDataTransformer = $detailOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*']),
            $this->detailOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->detailInPutDataTransformer);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->create($resource),
                $this->detailOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->detailOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->detailInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->detailOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->delete($id),
            $this->detailOutPutDataTransformer
        );
    }
}