<?php

namespace App\Services;

use App\CommunityManager;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class CommunityManagerService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $communityManagerOutPutDataTransformer;
    protected $communityManagerInPutDataTransformer;

    public function __construct(CommunityManager $communityManager,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $communityManagerInPutDataTransformer,
                                OutPutDataTransformer $communityManagerOutPutDataTransformer)
    {
        $this->repository = new Repository($communityManager);
        $this->dataTransformer = $dataTransformer;
        $this->communityManagerInPutDataTransformer = $communityManagerInPutDataTransformer;
        $this->communityManagerOutPutDataTransformer = $communityManagerOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return object \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*']),
            $this->communityManagerOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->communityManagerInPutDataTransformer);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->create($resource),
                $this->communityManagerOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return object \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->communityManagerOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return object \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->communityManagerInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->communityManagerOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return object \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->delete($id),
            $this->communityManagerOutPutDataTransformer
        );
    }
}