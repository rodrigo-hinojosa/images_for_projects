<?php

namespace App\Services;

use App\ContentType;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class ContentTypeService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $contentTypeOutPutDataTransformer;
    protected $contentTypeInPutDataTransformer;

    public function __construct(ContentType $contentType,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $contentTypeInPutDataTransformer,
                                OutPutDataTransformer $contentTypeOutPutDataTransformer)
    {
        $this->repository = new Repository($contentType);
        $this->dataTransformer = $dataTransformer;
        $this->contentTypeInPutDataTransformer = $contentTypeInPutDataTransformer;
        $this->contentTypeOutPutDataTransformer = $contentTypeOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*']),
            $this->contentTypeOutPutDataTransformer
        );
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function slimIndexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['id', 'name']),
            $this->contentTypeOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->contentTypeInPutDataTransformer);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->create($resource),
                $this->contentTypeOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->contentTypeOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->contentTypeInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->contentTypeOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        /**
         * Check if ContentType have relationship with other model (can´t remove if exist)
         *
         */
        if ($this->repository->with('contents')->find($id)->contents->first()) :
            return response()->json(
                ['integrity_reference' => true]
                , 400
            );
        else :
            return $this->dataTransformer->itemDataTransformer(
                $this->repository->delete($id),
                $this->contentTypeOutPutDataTransformer
            );
        endif;
    }
}