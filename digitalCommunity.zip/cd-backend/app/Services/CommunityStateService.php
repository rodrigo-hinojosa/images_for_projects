<?php

namespace App\Services;

use App\CommunityState;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class CommunityStateService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $communityStateInPutDataTransformer;
    protected $communityStateOutPutDataTransformer;

    public function __construct(CommunityState $communityState,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $communityStateInPutDataTransformer,
                                OutPutDataTransformer $communityStateOutPutDataTransformer)
    {
        $this->repository = new Repository($communityState);
        $this->dataTransformer = $dataTransformer;
        $this->communityStateInPutDataTransformer = $communityStateInPutDataTransformer;
        $this->communityStateOutPutDataTransformer = $communityStateOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*']),
            $this->communityStateOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->communityStateInPutDataTransformer);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->create($resource),
                $this->communityStateOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->communityStateOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->communityStateInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->communityStateOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        /**
         * Check if CommunityState have relationship with other model (can´t remove if exist)
         *
         */
        if ($this->repository->with('communities')->find($id)->communities->first()) :
            return response()->json(
                ['integrity_reference' => true]
                , 400
            );
        else :
            return $this->dataTransformer->itemDataTransformer(
                $this->repository->delete($id),
                $this->communityStateOutPutDataTransformer
            );
        endif;
    }
}