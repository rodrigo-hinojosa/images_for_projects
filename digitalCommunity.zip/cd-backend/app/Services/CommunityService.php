<?php

namespace App\Services;

use App\Community;
use App\Repositories\Repository;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class CommunityService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $communityInPutDataTransformer;
    protected $communityOutPutDataTransformer;

    public function __construct(Community $community,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $communityInPutDataTransformer,
                                OutPutDataTransformer $communityOutPutDataTransformer)
    {
        $this->repository = new Repository($community);
        $this->dataTransformer = $dataTransformer;
        $this->communityInPutDataTransformer = $communityInPutDataTransformer;
        $this->communityOutPutDataTransformer = $communityOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Repositories\Repository@all
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['id', 'father_community_id', 'community_state_id', 'name', 'url']),
            $this->communityOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \App\Repositories\Repository@create
     */
    public function storeService($data)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->communityInPutDataTransformer);

        $newCommunity = $this->repository->create($resource);

        $newCommunity['api_key'] = Hash::make($newCommunity->id);

        return response()->json(
            $this->dataTransformer->itemDataTransformer(
                $this->repository->modify($newCommunity->toArray(), $newCommunity->id),
                $this->communityOutPutDataTransformer),
            201
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@get
     */
    public function showService($id)
    {
        return $this->dataTransformer->itemDataTransformer(
            $this->repository->get($id),
            $this->communityOutPutDataTransformer
        );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        $resource = $this->dataTransformer->itemDataTransformer($data, $this->communityInPutDataTransformer);

        return $this->dataTransformer->itemDataTransformer(
            $this->repository->modify($resource, $id),
            $this->communityOutPutDataTransformer
        );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        /**
         * Check if Community have relationship with other model (can´t remove if exist)
         *
         */
        if ($this->repository->with('users')->find($id)->users->first()) :
            return response()->json(
                ['integrity_reference' => true]
                , 400
            );
        else :
            return $this->dataTransformer->itemDataTransformer(
                $this->repository->delete($id),
                $this->communityOutPutDataTransformer
            );
        endif;
    }

    /**
     * Display a listing of the resource by relation with other model.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@all
     */
    public function getCommunitiesByStatusService($id)
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['id', 'community_state_id', 'name', 'url'])->where('community_state_id', $id),
            $this->communityOutPutDataTransformer
        );
    }

    /**
     * Display a listing of the resource by relation with other model.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@with
     */
    public function getPagesForIndexByCommunityService($id)
    {
        return DB::table('pages')->
        select('id', 'name', 'api_key as apiKey')->where('community_id', $id)->whereNull('deleted_at')->whereNotExists(function ($query) {
            $query->select(DB::raw(1))
                ->from('details')
                ->whereRaw('details.page_id = pages.id');
        })->get();
    }

    /**
     * Display a listing of the resource by relation with other model.
     *
     * @param  int $id
     * @return \App\Repositories\Repository@with
     */
    public function getPagesForDetailByCommunityService($id)
    {
        return DB::table('pages')->
        select('id', 'name', 'api_key as apiKey')->where('community_id', $id)->whereNull('deleted_at')->whereNotExists(function ($query) {
            $query->select(DB::raw(1))
                ->from('frames')
                ->whereRaw('frames.page_id = pages.id');
        })->get();
    }

    /**
     * Display a JSON response with boolean check by domain
     *
     * @return String
     */
    public function checkIfDomainExistsService($domain)
    {
        if ($this->isDomainAvailable($domain)) :
            return response()->json(
                ['isDomainAvailable' => true]
                , 200
            );
        else :
            return response()->json(
                ['isDomainAvailable' => false]
                , 200
            );
        endif;
    }

    /**
     * Return TRUE is Community ID, key and domain
     *
     * @param  string $key
     * @param  string $domain
     *
     * @return Boolean
     */
    public static function checkCommunityApiAccessByKeyService($key, $domain)
    {
        $domain = CommunityService::addStringDomain($domain);

        $community = DB::table('communities')->where('url', $domain)->first();

        if ($community) :

            if (Hash::check($community->id, $key)) :

                return true;

            else :

                return false;

            endif;

        else :

            return false;

        endif;
    }

    /**
     * Return Community ID by key and domain
     *
     * @param  string $key
     * @param  string $domain
     *
     * @return int
     */
    public function getCommunityIdByKeyService($key, $domain)
    {
        $domain = CommunityService::addStringDomain($domain);

        $community = DB::table('communities')->where('url', $domain)->first();

        if ($community) :

            if (Hash::check($community->id, $key)) :

                return $community->id;

            else :

                return 0;

            endif;

        else :

            return 0;

        endif;

    }

    /**
     * Add / to final domain string
     *
     * @param  string $domain
     *
     * @return string $domain
     */
    private static function addStringDomain($domain)
    {
        if (substr($domain, -1) !== '/') :

            $domain = $domain . '/';

        endif;

        return $domain;
    }

    /**
     * Return TRUE is domain its availible
     *
     * @param  string $domain
     *
     * @return Boolean
     */
    private function isDomainAvailable($domain)
    {
//        if (checkdnsrr($domain, 'ANY')) :
//            return true;
//        else :
//            return false;
//        endif;
        return true;
    }

    /**
     * Return Communities List by Community admin active
     *
     * @return array @DB::select
     */
    public function getHierarchicalNodesByCommunityServices()
    {
//        $user = app('auth')->guard()->user();
//
//        $communityManagerActive = DB::table('community_managers')
//            ->where([['user_id', $user->id], ['status', 1]])
//            ->whereNull('deleted_at')
//            ->first();

        $nodeCommunity = DB::select('call get_all_communities_children_by_father_community(?)', [1]);

        return response($nodeCommunity);

    }

}