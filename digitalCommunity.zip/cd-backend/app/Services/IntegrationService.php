<?php

namespace App\Services;

use App\Integration;
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;
use App\Repositories\Repository;
use App\Transformer\DataTransformer;
use App\Transformer\InPutDataTransformer;
use App\Transformer\OutPutDataTransformer;

class IntegrationService implements ServiceInterface
{
    protected $repository;
    protected $dataTransformer;
    protected $integrationOutPutDataTransformer;
    protected $integrationInPutDataTransformer;

    protected $awsConfig;
    protected $awsBucketName;

    public function __construct(Integration $integration,
                                DataTransformer $dataTransformer,
                                InPutDataTransformer $integrationInPutDataTransformer,
                                OutPutDataTransformer $integrationOutPutDataTransformer)
    {
        $this->awsConfig = config('aws');
        $this->awsBucketName = 'cd-integration';
        $this->repository = new Repository($integration);
        $this->dataTransformer = $dataTransformer;
        $this->integrationInPutDataTransformer = $integrationInPutDataTransformer;
        $this->integrationOutPutDataTransformer = $integrationOutPutDataTransformer;
    }

    /**
     * Display a listing of the resource.
     *
     * @return object \League\Fractal\Manager
     */
    public function indexService()
    {
        return $this->dataTransformer->collectionDataTransformer(
            $this->repository->all(['*']),
            $this->integrationOutPutDataTransformer
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  object $data
     * @return array response()
     */
    public function storeService($data)
    {
        $data['fileName'] = $this->generateNewNameToFile($data->file('file')->getClientOriginalName());

        $uploadFileToS3 = $this->uploadFileToBucketS3Service($data);

        if ($uploadFileToS3 === true) :

            unset($data->file);

            $resource = $this->dataTransformer->itemDataTransformer($data->ToArray(), $this->integrationInPutDataTransformer);

            return response()->json(
                $this->dataTransformer->itemDataTransformer(
                    $this->repository->create($resource),
                    $this->integrationOutPutDataTransformer),
                201
            );

        else:

            return response('', 500);

        endif;
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return object \Illuminate\Database\Eloquent\Model
     */
    public function showService($id)
    {
        return $this->repository->get($id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return array \App\Repositories\Repository
     */
    public function downloadFileService($id)
    {
        return $this->getFileForDownloadFromBucketS3Service($this->showService($id)->file_name);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  array $data
     * @param  int $id
     * @return array \App\Repositories\Repository@modify
     */
    public function updateService($data, $id)
    {
        if ($data->file('file')) :

            $data['fileName'] = $this->generateNewNameToFile($data->file('file')->getClientOriginalName());

            $uploadFileToS3 = $this->uploadFileToBucketS3Service($data);

            if ($uploadFileToS3 === true) :

                $this->removeFileToBucketS3Service($this->showService($id)->file_name);

                unset($data->file);

                $resource = $this->dataTransformer->itemDataTransformer($data->ToArray(), $this->integrationInPutDataTransformer);

                return response()->json(
                    $this->dataTransformer->itemDataTransformer(
                        $this->repository->modify($resource, $id),
                        $this->integrationOutPutDataTransformer),
                    200
                );

            else:

                return response('', 500);

            endif;

        else:

            $resource = $this->dataTransformer->itemDataTransformer($data->ToArray(), $this->integrationInPutDataTransformer);

            return response()->json(
                $this->dataTransformer->itemDataTransformer(
                    $this->repository->modify($resource, $id),
                    $this->integrationOutPutDataTransformer),
                200
            );

        endif;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return array \App\Repositories\Repository@delete
     */
    public function destroyService($id)
    {
        if ($removeFileToS3 = $this->removeFileToBucketS3Service($this->showService($id)->file_name)) :

            return response()->json(
                $this->dataTransformer->itemDataTransformer(
                    $this->repository->delete($id),
                    $this->integrationOutPutDataTransformer),
                200
            );

        else:

            return $removeFileToS3;

        endif;
    }

    /**
     * Get Object from S3 bucket to Download
     *
     * @return array $response
     */
    private function getFileForDownloadFromBucketS3Service($fileName)
    {
        try {

            $contentDisposition = 'attachment; filename=' . $fileName;

            $s3Client = new S3Client($this->awsConfig);

            $object = $s3Client->getObject([
                'Bucket' => $this->awsBucketName,
                'Key' => $fileName,
                'ResponseContentDisposition' => $contentDisposition,
                'ResponseCacheControl' => 'No-cache',
                'ResponseExpires' => gmdate(DATE_RFC2822, time() + 3600)
            ]);

            $headers = [
                'Content-Description' => 'File Transfer',
                'Content-Disposition' => $contentDisposition,
                'filename' => $fileName,
                'Content-Transfer-Encoding' => 'binary',
                'Cache-Control' => 'no-cache, no-store, must-revalidate'
            ];

            $response = response($object->get('Body'), 200, $headers);

        } catch (S3Exception $e) {

            $response = response($e->getMessage(), 500);
        }

        return $response;
    }

    /**
     * Put Object from App to S3 Bucket
     *
     * @return boolean
     */
    private function uploadFileToBucketS3Service($file)
    {
        try {

            $s3Client = new S3Client($this->awsConfig);

            $s3Client->putObject([
                'Bucket' => $this->awsBucketName,
                'Key' => $file->fileName,
                'Body' => fopen($file->file('file'), 'rb')
            ]);

            return true;

        } catch (S3Exception $e) {

            return false;

        }
    }

    /**
     * Remove Object from S3 bucket
     *
     * @return boolean
     */
    private function removeFileToBucketS3Service($fileName)
    {
        try {

            $s3Client = new S3Client($this->awsConfig);

            $s3Client->deleteObject([
                'Bucket' => $this->awsBucketName,
                'Key' => $fileName
            ]);

            return true;

        } catch (S3Exception $e) {

            return false;

        }
    }

    /**
     * Generate a new name to file
     *
     * @param  $name string
     * @param  $fileName string
     *
     * @return string
     */
    private function generateNewNameToFile($fileName)
    {
        $fileNameArray = explode('.', $fileName);

        return $fileNameArray[0] . '_' . round(microtime(true)) . '.' . $fileNameArray[1];
    }
}