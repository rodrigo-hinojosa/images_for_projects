<?php

namespace App\Http\Controllers;

use App\Services\ContentStateService;
use App\Http\Requests\ContentStateRequestStore;
use App\Http\Requests\ContentStateRequestUpdate;

class ContentStateController extends Controller
{
    protected $contentStateService;

    public function __construct(ContentStateService $contentStateService)
    {
        $this->contentStateService = $contentStateService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\ContentStateService@indexService
     */
    public function index()
    {
        return $this->contentStateService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\ContentStateRequestStore $request
     * @return \App\Services\ContentStateService@storeService
     */
    public function store(ContentStateRequestStore $request)
    {
        return $this->contentStateService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Services\ContentStateService@showService
     */
    public function show($id)
    {
        return $this->contentStateService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\ContentStateRequestUpdate $request
     * @param  int $id
     * @return \App\Services\ContentStateService@updateService
     */
    public function update(ContentStateRequestUpdate $request, $id)
    {
        return $this->contentStateService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Services\ContentStateService@destroyService
     */
    public function destroy($id)
    {
        return $this->contentStateService->destroyService($id);
    }
}
