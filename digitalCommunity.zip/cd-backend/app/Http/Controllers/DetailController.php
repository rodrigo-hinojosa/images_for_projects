<?php

namespace App\Http\Controllers;

use App\Services\DetailService;
use App\Http\Requests\DetailRequestStore;
use App\Http\Requests\DetailRequestUpdate;

class DetailController extends Controller
{
    protected $detailService;

    public function __construct(DetailService $detailService)
    {
        $this->frameService = $detailService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\DetailService@indexService
     */
    public function index()
    {
        return $this->frameService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\DetailRequestStore $request
     * @return \App\Services\DetailService@storeService
     */
    public function store(DetailRequestStore $request)
    {
        return $this->frameService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Services\DetailService@showService
     */
    public function show($id)
    {
        return $this->frameService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\DetailRequestUpdate $request
     * @param  int $id
     * @return \App\Services\DetailService@updateService
     */
    public function update(DetailRequestUpdate $request, $id)
    {
        return $this->frameService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Services\DetailService@destroyService
     */
    public function destroy($id)
    {
        return $this->frameService->destroyService($id);
    }
}
