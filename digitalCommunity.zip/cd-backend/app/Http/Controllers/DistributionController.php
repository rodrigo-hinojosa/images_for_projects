<?php

namespace App\Http\Controllers;

use App\Services\DistributionService;
use App\Http\Requests\DistributionRequestStore;
use App\Http\Requests\DistributionRequestUpdate;

class DistributionController extends Controller
{
    protected $distributionService;

    public function __construct(DistributionService $distributionService)
    {
        $this->distributionService = $distributionService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\DistributionService@indexService
     */
    public function index()
    {
        return $this->distributionService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\DistributionRequestStore $request
     * @return \App\Services\DistributionService@storeService
     */
    public function store(DistributionRequestStore $request)
    {
        return $this->distributionService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Services\DistributionService@showService
     */
    public function show($id)
    {
        return $this->distributionService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\DistributionRequestUpdate $request
     * @param  int $id
     * @return \App\Services\DistributionService@updateService
     */
    public function update(DistributionRequestUpdate $request, $id)
    {
        return $this->distributionService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Services\DistributionService@destroyService
     */
    public function destroy($id)
    {
        return $this->distributionService->destroyService($id);
    }
}
