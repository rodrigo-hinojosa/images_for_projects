<?php

namespace App\Http\Controllers;

use App\Services\CommunityStateService;
use App\Http\Requests\CommunityStateRequestStore;
use App\Http\Requests\CommunityStateRequestUpdate;

class CommunityStateController extends Controller
{
    protected $communityStateService;

    public function __construct(CommunityStateService $communityStateService)
    {
        $this->communityStateService = $communityStateService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\CommunityStateService@indexService
     */
    public function index()
    {
        return $this->communityStateService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\CommunityStateRequestStore $request
     * @return \App\Services\CommunityStateService@storeService
     */
    public function store(CommunityStateRequestStore $request)
    {
        return $this->communityStateService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Services\CommunityStateService@showService
     */
    public function show($id)
    {
        return $this->communityStateService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\CommunityStateRequestUpdate $request
     * @param  int $id
     * @return \App\Services\CommunityStateService@updateService
     */
    public function update(CommunityStateRequestUpdate $request, $id)
    {
        return $this->communityStateService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Services\CommunityStateService@destroyService
     */
    public function destroy($id)
    {
        return $this->communityStateService->destroyService($id);
    }
}
