<?php

namespace App\Http\Controllers;

use App\Services\CommunityManagerService;
use App\Http\Requests\CommunityManagerStore;
use App\Http\Requests\CommunityManagerUpdate;

class CommunityManagerController extends Controller
{
    protected $communityManagerService;

    public function __construct(CommunityManagerService $communityManagerService)
    {
        $this->communityManagerService = $communityManagerService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return object \App\Services\CommunityManagerService@indexService
     */
    public function index()
    {
        return $this->communityManagerService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\CommunityManagerStore $request
     * @return object \App\Services\CommunityManagerUpdate@storeService
     */
    public function store(CommunityManagerStore $request)
    {
        return $this->communityManagerService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return object \App\Services\CommunityManagerService@showService
     */
    public function show($id)
    {
        return $this->communityManagerService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\CommunityManagerUpdate $request
     * @param  int $id
     * @return object \App\Services\CommunityManagerService@updateService
     */
    public function update(CommunityManagerUpdate $request, $id)
    {
        return $this->communityManagerService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return object \App\Services\CommunityManagerService@destroyService
     */
    public function destroy($id)
    {
        return $this->communityManagerService->destroyService($id);
    }
}
