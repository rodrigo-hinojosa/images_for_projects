<?php

namespace App\Http\Controllers;

use App\Services\CommunityService;
use App\Http\Requests\CommunityRequestStore;
use App\Http\Requests\CommunityRequestUpdate;
use App\Http\Requests\CommunityRequestCheckDomain;
use App\Http\Requests\CommunityRequestActivateIntegration;

class CommunityController extends Controller
{
    protected $communityService;

    public function __construct(CommunityService $communityService)
    {
        $this->communityService = $communityService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return object \App\Services\CommunityService@indexService
     */
    public function index()
    {
        return $this->communityService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\CommunityRequestStore $request
     * @return object \App\Services\CommunityService@storeService
     */
    public function store(CommunityRequestStore $request)
    {
        return $this->communityService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return object \App\Services\CommunityService@showService
     */
    public function show($id)
    {
        return $this->communityService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\CommunityRequestUpdate $request
     * @param  int $id
     * @return object \App\Services\CommunityService@updateService
     */
    public function update(CommunityRequestUpdate $request, $id)
    {
        return $this->communityService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return object \App\Services\CommunityService@destroyService
     */
    public function destroy($id)
    {
        return $this->communityService->destroyService($id);
    }

    /**
     * Display a listing of the resource by relationship
     *
     * @param  int $id
     * @return object \App\Services\CommunityService@getCommunitiesByStatusService
     */
    public function getCommunitiesByStatus($id)
    {
        return $this->communityService->getCommunitiesByStatusService($id);
    }

    /**
     * Display a listing of the resource by relationship
     *
     * @param  int $id
     * @return object \App\Services\CommunityService@getPagesForDetailByCommunityService
     */
    public function getPagesForIndexByCommunity($id)
    {
        return $this->communityService->getPagesForIndexByCommunityService($id);
    }

    /**
     * Display a listing of the resource by relationship
     *
     * @param  int $id
     * @return object \App\Services\CommunityService@getPagesForDetailByCommunityService
     */
    public function getPagesForDetailByCommunity($id)
    {
        return $this->communityService->getPagesForDetailByCommunityService($id);
    }

    /**
     * Display a JSON response with boolean check by Domain
     *
     * @param  \App\Http\Requests\CommunityRequestCheckDomain $request
     * @return string \App\Services\CommunityService@checkIfDomainExistsService
     */
    public function checkIfDomainExists(CommunityRequestCheckDomain $request)
    {
        return $this->communityService->checkIfDomainExistsService($request->domain);
    }

    /**
     * Get a community ID when key and domain check hash success
     *
     * @param  \App\Http\Requests\CommunityRequestActivateIntegration $request
     * @return int \App\Services\CommunityService@checkIfDomainExistsService
     */
    public function getCommunityIdByKey(CommunityRequestActivateIntegration $request)
    {
        return $this->communityService->getCommunityIdByKeyService($request->key, $request->domain);
    }

    /**
     * Get Communities List by Community admin active
     *
     * @return object \App\Services\getHierarchicalNodesByCommunityServices
     */
    public function getHierarchicalNodesByCommunity()
    {
        return $this->communityService->getHierarchicalNodesByCommunityServices();
    }
}
