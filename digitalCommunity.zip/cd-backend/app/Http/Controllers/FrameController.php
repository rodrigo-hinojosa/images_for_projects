<?php

namespace App\Http\Controllers;

use App\Services\FrameService;
use App\Http\Requests\FrameRequestStore;
use App\Http\Requests\FrameRequestUpdate;

class FrameController extends Controller
{
    protected $frameService;

    public function __construct(FrameService $frameService)
    {
        $this->frameService = $frameService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\FrameService@indexService
     */
    public function index()
    {
        return $this->frameService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\FrameRequestStore $request
     * @return \App\Services\FrameService@storeService
     */
    public function store(FrameRequestStore $request)
    {
        return $this->frameService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Services\FrameService@showService
     */
    public function show($id)
    {
        return $this->frameService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\FrameRequestUpdate $request
     * @param  int $id
     * @return \App\Services\FrameService@updateService
     */
    public function update(FrameRequestUpdate $request, $id)
    {
        return $this->frameService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Services\FrameService@destroyService
     */
    public function destroy($id)
    {
        return $this->frameService->destroyService($id);
    }

    /**
     * Display a listing of the resource by relationship
     *
     * @param  int $id
     * @return \App\Services\FrameService@getFramesByPageService
     */
    public function getFramesByPage($id)
    {
        return $this->frameService->getFramesByPageService($id);
    }
}
