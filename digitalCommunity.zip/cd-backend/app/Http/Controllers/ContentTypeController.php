<?php

namespace App\Http\Controllers;

use App\Services\ContentTypeService;
use App\Http\Requests\ContentTypeRequestStore;
use App\Http\Requests\ContentTypeRequestUpdate;

class ContentTypeController extends Controller
{
    protected $contentTypeService;

    public function __construct(ContentTypeService $contentTypeService)
    {
        $this->contentTypeService = $contentTypeService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\ContentTypeService@indexService
     */
    public function index()
    {
        return $this->contentTypeService->indexService();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\ContentTypeService@indexService
     */
    public function slimIndex()
    {
        return $this->contentTypeService->slimIndexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\ContentTypeRequestStore $request
     * @return \App\Services\ContentTypeService@storeService
     */
    public function store(ContentTypeRequestStore $request)
    {
        return $this->contentTypeService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Services\ContentTypeService@showService
     */
    public function show($id)
    {
        return $this->contentTypeService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\ContentTypeRequestUpdate $request
     * @param  int $id
     * @return \App\Services\ContentTypeService@updateService
     */
    public function update(ContentTypeRequestUpdate $request, $id)
    {
        return $this->contentTypeService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Services\ContentTypeService@destroyService
     */
    public function destroy($id)
    {
        return $this->contentTypeService->destroyService($id);
    }
}
