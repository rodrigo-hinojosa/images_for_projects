<?php

namespace App\Http\Controllers;

use App\Services\PageService;
use App\Http\Requests\PageRequestStore;
use App\Http\Requests\PageRequestUpdate;
use App\Http\Requests\PageRequestCheckPage;

class PageController extends Controller
{
    protected $pageService;

    public function __construct(PageService $pageService)
    {
        $this->pageService = $pageService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\PageService@indexService
     */
    public function index()
    {
        return $this->pageService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\PageRequestStore $request
     * @return \App\Services\PageService@storeService
     */
    public function store(PageRequestStore $request)
    {
        return $this->pageService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \App\Services\PageService@showService
     */
    public function show($id)
    {
        return $this->pageService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\PageRequestUpdate $request
     * @param  int $id
     * @return \App\Services\PageService@updateService
     */
    public function update(PageRequestUpdate $request, $id)
    {
        return $this->pageService->updateService($request->all(), $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Services\PageService@destroyService
     */
    public function destroy($id)
    {
        return $this->pageService->destroyService($id);
    }

    /**
     * Display a listing of the resource by relationship
     *
     * @param  int $id
     * @return \App\Services\PageService@getDetailByPageService
     */
    public function getDetailByPage($id)
    {
        return $this->pageService->getDetailByPageService($id);
    }

    /**
     * Display a JSON response with boolean check by URL page
     *
     * @param  \App\Http\Requests\PageRequestCheckPage $request
     * @return \App\Services\PageService@checkIfUrlPageExistsService
     */
    public function checkIfUrlPageExists(PageRequestCheckPage $request)
    {
        return $this->pageService->checkIfUrlPageExistsService($request->url);
    }
}
