<?php

namespace App\Http\Controllers;

use App\Services\IntegrationService;
use App\Http\Requests\IntegrationRequestStore;
use App\Http\Requests\IntegrationRequestUpdate;

class IntegrationController extends Controller
{
    protected $integrationService;

    public function __construct(IntegrationService $integrationService)
    {
        $this->integrationService = $integrationService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \App\Services\ContentTypeService@indexService
     */
    public function index()
    {
        return $this->integrationService->indexService();
    }

    /**
     * Download the specified resource.
     *
     * @param  int $id
     * @return \App\Services\IntegrationService@downloadFileService
     */
    public function downloadFile($id)
    {
        return $this->integrationService->downloadFileService($id);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\IntegrationRequestStore $request
     * @return \App\Services\IntegrationService@storeService
     */
    public function store(IntegrationRequestStore $request)
    {
        return $this->integrationService->storeService($request);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\FrameRequestUpdate $request
     * @param  int $id
     * @return \App\Services\FrameService@updateService
     */
    public function update(IntegrationRequestUpdate $request, $id)
    {
        return $this->integrationService->updateService($request, $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \App\Services\IntegrationService@destroyService
     */
    public function destroy($id)
    {
        return $this->integrationService->destroyService($id);
    }
}
