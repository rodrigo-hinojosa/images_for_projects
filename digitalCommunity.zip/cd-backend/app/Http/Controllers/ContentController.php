<?php

namespace App\Http\Controllers;

use App\Http\Requests\ContentRequestKeyPaginate;
use App\Services\ContentService;
use App\Http\Requests\ContentRequestKey;
use App\Http\Requests\ContentRequestStore;
use App\Http\Requests\ContentRequestUpdate;
use App\Http\Requests\ContentRequestGetContentAssociated;
use App\Http\Requests\ContentRequestGetContentNotAssociated;

class ContentController extends Controller
{
    protected $contentService;

    public function __construct(ContentService $contentService)
    {
        $this->contentService = $contentService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return object \App\Services\ContentService@indexService
     */
    public function index()
    {
        return $this->contentService->indexService();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\ContentRequestStore $request
     *
     * @return object \App\Services\ContentService@storeService
     */
    public function store(ContentRequestStore $request)
    {
        return $this->contentService->storeService($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return object \App\Services\ContentService@showService
     */
    public function show($id)
    {
        return $this->contentService->showService($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\ContentRequestUpdate $request
     * @param  int $idInnerContent
     * @param  int $idCommunity
     *
     * @return object \App\Services\ContentService@updateContentIdByInnerContentService
     */
    public function update(ContentRequestUpdate $request, $idInnerContent, $idCommunity)
    {
        return $this->contentService->updateContentIdByInnerContentService($request->all(), $idInnerContent, $idCommunity);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $idInnerContent
     * @param  int $idCommunity
     *
     * @return object \App\Services\ContentService@destroyContentIdByInnerContentService
     */
    public function destroy($idInnerContent, $idCommunity)
    {
        return $this->contentService->destroyContentIdByInnerContentService($idInnerContent, $idCommunity);
    }

    /**
     * restore the specified resource from storage.
     *
     * @param  int $idInnerContent
     * @param  int $idCommunity
     *
     * @return object \App\Services\ContentService@getContentIdByInnerContentService
     */
    public function restore($idInnerContent, $idCommunity)
    {
        return $this->contentService->restoreContentIdByInnerContentService($idInnerContent, $idCommunity);
    }

    /**
     * Get content by Api ID
     *
     * @param  \App\Http\Requests\ContentRequestKey $request
     * @return object \App\Services\ContentService@ApiDetailContentsService
     */
    public function apiDetailContents(ContentRequestKey $request)
    {
        return $this->contentService->apiDetailContentsService($request->key, $request->domain, $request->idContent);
    }


    /**
     * Get contents index by Api KEY
     *
     * @param  \App\Http\Requests\ContentRequestKey $request
     * @return object \App\Services\ContentService@ApiIndexContentsService
     */
    public function apiIndexContents(ContentRequestKey $request)
    {
        return $this->contentService->apiIndexContentsService($request);
    }

    /**
     * Get contents index by Api KEY
     *
     * @param  \App\Http\Requests\ContentRequestKeyPaginate $request
     * @return object \App\Services\ContentService@apiIndexByPaginationService
     */
    public function apiIndexContentsByPagination(ContentRequestKeyPaginate $request)
    {
        return $this->contentService->apiIndexContentsByPaginationService($request);
    }

    /**
     * Get Contents By Distribution
     *
     * @param  \App\Http\Requests\ContentRequestGetContentAssociated $request
     *
     * @return object \App\Services\ContentService@getContentsByCommunityAndContentTypesService
     */
    public function getContentsByCommunityAndContentTypes(ContentRequestGetContentAssociated $request)
    {
        return $this->contentService->getContentsByCommunityAndContentTypesService($request);
    }

    /**
     * Get Contents For Distribution
     *
     * @param  \App\Http\Requests\ContentRequestGetContentNotAssociated $request
     *
     * @return \App\Services\ContentService@getContentsByNotCommunityAndContentTypesService
     */
    public function getContentsByNotCommunityAndContentTypes(ContentRequestGetContentNotAssociated $request)
    {
        return $this->contentService->getContentsByNotCommunityAndContentTypesService($request);
    }
}
