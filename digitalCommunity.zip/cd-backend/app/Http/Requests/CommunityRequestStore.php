<?php

namespace App\Http\Requests;

use Pearl\RequestValidate\RequestAbstract;

class CommunityRequestStore extends RequestAbstract
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'fatherCommunityId' => 'numeric',
            'communityStateId' => 'required|numeric',
            'url' => 'required|max:255|unique:communities,url,NULL,id,deleted_at,NULL',
            'urlBackOffice' => 'required|max:255|unique:communities,url_back_office,NULL,id,deleted_at,NULL',
            'name' => 'required|max:100|unique:communities,name,NULL,id,deleted_at,NULL',
            'addres' => 'max:100',
            'phone' => 'max:100',
            'image' => 'max:2047',
            'email' => 'max:100',
            'description' => 'max:2000'
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            //
        ];
    }
}
