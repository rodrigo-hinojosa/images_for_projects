<?php

namespace App\Http\Requests;

use Pearl\RequestValidate\RequestAbstract;

class DetailRequestUpdate extends RequestAbstract
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $idUrl = $this->segment(2);

        return [
            'pageId' => 'required|numeric|unique:details,page_id,' . $idUrl . ',id,deleted_at,NULL',
            'identifier' => 'required|max:50'
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            //
        ];
    }
}
