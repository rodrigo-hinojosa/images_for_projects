<?php

namespace App\Http\Requests;

use Pearl\RequestValidate\RequestAbstract;

class ContentRequestKeyPaginate extends RequestAbstract
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'key' => 'required|min:60|max:60',
            'domain' => 'required|max:255',
            'contentTypeId' => 'required:integer'
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'key.required' => 'error',
            'key.min' => 'error',
            'key.max' => 'error',
            'domain.required' => 'error',
            'domain.max' => 'error'
        ];
    }
}
