<?php

namespace App\Http\Middleware;

use Closure;
use App\Services\CommunityService;

class AuthorizeApiContentIntegration
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($request->header('Authorization') && $request->header('Domain-Auth')) :

            if (CommunityService::checkCommunityApiAccessByKeyService(
                $request->header('Authorization'),
                $request->header('Domain-Auth'))) :

                return $next($request);

            else :

                return response('Unauthorized.', 401);

            endif;

        else :

            return response('Bad Request', 400);

        endif;
    }
}
