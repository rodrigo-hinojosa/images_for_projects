<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Frame extends Model
{
    use SoftDeletes;

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'page_id',
        'content_type_id',
        'publicity_id',
        'identifier'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'created_at',
        'updated_at',
        'deleted_at'
    ];

    /**
     * Relationship with ContentType model
     */
    public function contentType()
    {
        return $this->belongsTo(ContentType::class);
    }

    /**
     * Relationship with Page model
     */
    public function page()
    {
        return $this->belongsTo(Page::class);
    }
}
