<?php

return [
    'version' => 'latest',
    'region' => 'us-east-2',
    'credentials' => [
        'key' => 'AKIAJD4PR7KGFZDOJILA',
        'secret' => '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'
    ],

//     You can override settings for specific services
//    'Ses' => [
//        'region' => 'us-east-1',
//    ]
];
