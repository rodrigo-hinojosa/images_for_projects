<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

/**
 * router for IntegrationController
 *
 * @return \Illuminate\Http\Response
 */
$router->group(['prefix' => 'integration', 'middleware' => ['auth:api']], function () use ($router) {
    $router->get('', ['uses' => 'IntegrationController@index']);
    $router->get('{id}', ['uses' => 'IntegrationController@downloadFile']);
    $router->post('', ['uses' => 'IntegrationController@store']);
    $router->post('{id}', ['uses' => 'IntegrationController@update']);
    $router->delete('{id}', ['uses' => 'IntegrationController@destroy']);
});

$router->group(['middleware' => ['ctjr']], function () use ($router) {

    /**
     * router of API KEY checkpage
     *
     * @return \Illuminate\Http\Response
     */
    $router->group(['prefix' => 'key'], function () use ($router) {
        $router->post('index', ['uses' => 'ContentController@apiIndexContents']);
        $router->post('paginate', ['uses' => 'ContentController@apiIndexContentsByPagination']);
        $router->post('detail', ['uses' => 'ContentController@apiDetailContents']);
    });

    /**
     * router of API PUBLIC MANAGE CONTENT
     *
     * @return \Illuminate\Http\Response
     */
    $router->group(['prefix' => 'sync'], function () use ($router) {

        $router->group(['prefix' => 'communities'], function () use ($router) {
            $router->post('', ['uses' => 'CommunityController@getCommunityIdByKey']);
        });

        $router->group(['middleware' => ['authIntegration']], function () use ($router) {

            $router->group(['prefix' => 'contents'], function () use ($router) {

                $router->post('', ['uses' => 'ContentController@store']);
                $router->put('{innerContentId}/communities/{communityId}', ['uses' => 'ContentController@update']);
                $router->delete('{innerContentId}/communities/{communityId}', ['uses' => 'ContentController@destroy']);
                $router->post('restore/{innerContentId}/communities/{communityId}', ['uses' => 'ContentController@restore']);

            });

            $router->group(['prefix' => 'contenttypes'], function () use ($router) {
                $router->get('', ['uses' => 'ContentTypeController@slimIndex']);
            });

        });

    });

    /**
     * router of API with auth
     *
     */
    $router->group(['middleware' => ['auth:api']], function () use ($router) {

        /**
         * router for user data by token
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'communities/hierarchy'], function () use ($router) {
            $router->get('', ['uses' => 'CommunityController@getHierarchicalNodesByCommunity']);
        });

        /**
         * router for user data by token
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'auth/user'], function () use ($router) {
            $router->get('', ['uses' => 'UserController@getUserByAccessToken']);
        });

        /**
         * router list of ContentController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'contents'], function () use ($router) {
            $router->get('', ['uses' => 'ContentController@index']);
            $router->post('include', ['uses' => 'ContentController@getContentsByCommunityAndContentTypes']);
            $router->post('exclude', ['uses' => 'ContentController@getContentsByNotCommunityAndContentTypes']);
        });

        /**
         * router list of ContentStateController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'contentstates'], function () use ($router) {
            $router->get('', ['uses' => 'ContentStateController@index']);
            $router->get('{id}', ['uses' => 'ContentStateController@show']);
            $router->post('', ['uses' => 'ContentStateController@store']);
            $router->put('{id}', ['uses' => 'ContentStateController@update']);
            $router->delete('{id}', ['uses' => 'ContentStateController@destroy']);
        });

        /**
         * router list of ContentTypeController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'contenttypes'], function () use ($router) {
            $router->get('', ['uses' => 'ContentTypeController@index']);
            $router->get('{id}', ['uses' => 'ContentTypeController@show']);
            $router->post('', ['uses' => 'ContentTypeController@store']);
            $router->put('{id}', ['uses' => 'ContentTypeController@update']);
            $router->delete('{id}', ['uses' => 'ContentTypeController@destroy']);
        });

        /**
         * router list of CommunityController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'communities'], function () use ($router) {
            $router->get('', ['uses' => 'CommunityController@index']);
            $router->get('{id}', ['uses' => 'CommunityController@show']);
            $router->post('', ['uses' => 'CommunityController@store']);
            $router->put('{id}', ['uses' => 'CommunityController@update']);
            $router->delete('{id}', ['uses' => 'CommunityController@destroy']);

            $router->get('{id}/pages/index', ['uses' => 'CommunityController@getPagesForIndexByCommunity']);
            $router->get('{id}/pages/detail', ['uses' => 'CommunityController@getPagesForDetailByCommunity']);
            $router->get('{id}/status', ['uses' => 'CommunityController@getCommunitiesByStatus']);
            $router->post('/checkdomain', ['uses' => 'CommunityController@checkIfDomainExists']);
        });

        /**exclude
         * router list of CommunityManagerController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'communitymanagers'], function () use ($router) {
            $router->get('', ['uses' => 'CommunityManagerController@index']);
            $router->get('{id}', ['uses' => 'CommunityManagerController@show']);
            $router->post('', ['uses' => 'CommunityManagerController@store']);
            $router->put('{id}', ['uses' => 'CommunityManagerController@update']);
            $router->delete('{id}', ['uses' => 'CommunityManagerController@destroy']);
        });

        /**
         * router list of CommunityStateController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'communitystates'], function () use ($router) {
            $router->get('', ['uses' => 'CommunityStateController@index']);
            $router->get('{id}', ['uses' => 'CommunityStateController@show']);
            $router->post('', ['uses' => 'CommunityStateController@store']);
            $router->put('{id}', ['uses' => 'CommunityStateController@update']);
            $router->delete('{id}', ['uses' => 'CommunityStateController@destroy']);
        });

        /**
         * router list of DetailController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'details'], function () use ($router) {
            $router->get('', ['uses' => 'DetailController@index']);
            $router->get('{id}', ['uses' => 'DetailController@show']);
            $router->post('', ['uses' => 'DetailController@store']);
            $router->put('{id}', ['uses' => 'DetailController@update']);
            $router->delete('{id}', ['uses' => 'DetailController@destroy']);
        });

        /**
         * router list of DistributionController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'distributions'], function () use ($router) {
            $router->get('', ['uses' => 'DistributionController@index']);
            $router->get('{id}', ['uses' => 'DistributionController@show']);
            $router->post('', ['uses' => 'DistributionController@store']);
            $router->put('{id}', ['uses' => 'DistributionController@update']);
            $router->delete('{id}', ['uses' => 'DistributionController@destroy']);
        });

        /**
         * router list of FrameController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'frames'], function () use ($router) {
            $router->get('', ['uses' => 'FrameController@index']);
            $router->get('{id}', ['uses' => 'FrameController@show']);
            $router->post('', ['uses' => 'FrameController@store']);
            $router->put('{id}', ['uses' => 'FrameController@update']);
            $router->delete('{id}', ['uses' => 'FrameController@destroy']);

            $router->get('{id}/pages', ['uses' => 'FrameController@getFramesByPage']);
        });

        /**
         * router list of PageController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'pages'], function () use ($router) {
            $router->get('', ['uses' => 'PageController@index']);
            $router->get('{id}', ['uses' => 'PageController@show']);
            $router->post('', ['uses' => 'PageController@store']);
            $router->put('{id}', ['uses' => 'PageController@update']);
            $router->delete('{id}', ['uses' => 'PageController@destroy']);

            $router->get('{id}/details', ['uses' => 'PageController@getDetailByPage']);
            $router->post('/checkpage', ['uses' => 'PageController@checkIfUrlPageExists']);
        });

        /**
         * router list of UserController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'users'], function () use ($router) {
            $router->get('', ['uses' => 'UserController@index']);
            $router->get('{id}', ['uses' => 'UserController@show']);
            $router->post('', ['uses' => 'UserController@store']);
            $router->put('{id}', ['uses' => 'UserController@update']);
            $router->put('/profile/{id}', ['uses' => 'UserController@updateProfile']);
            $router->put('/password/{id}', ['uses' => 'UserController@updatePassword']);
            $router->delete('{id}', ['uses' => 'UserController@destroy']);
        });

        /**
         * router list of UserStateController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'userstates'], function () use ($router) {
            $router->get('', ['uses' => 'UserStateController@index']);
            $router->get('{id}', ['uses' => 'UserStateController@show']);
            $router->post('', ['uses' => 'UserStateController@store']);
            $router->put('{id}', ['uses' => 'UserStateController@update']);
            $router->delete('{id}', ['uses' => 'UserStateController@destroy']);
        });

        /**
         * router list of UserTypeController
         *
         * @return \Illuminate\Http\Response
         */
        $router->group(['prefix' => 'usertypes'], function () use ($router) {
            $router->get('', ['uses' => 'UserTypeController@index']);
            $router->get('{id}', ['uses' => 'UserTypeController@show']);
            $router->post('', ['uses' => 'UserTypeController@store']);
            $router->put('{id}', ['uses' => 'UserTypeController@update']);
            $router->delete('{id}', ['uses' => 'UserTypeController@destroy']);
        });

    });

});
